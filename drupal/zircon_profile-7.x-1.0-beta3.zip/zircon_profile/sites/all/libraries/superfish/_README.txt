ABOUT:
------------------------------------------
This is the Superfish library for the Superfish module of the Drupal CMS.
http://drupal.org/project/superfish

CHANGELOG:
------------------------------------------
Version 1.0, 2011-03-23
---------------------
- Initial release.